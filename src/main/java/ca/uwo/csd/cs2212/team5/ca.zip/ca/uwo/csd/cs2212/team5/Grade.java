package ca.uwo.csd.cs2212.team5;

public class Grade implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1963245831664970835L;
	double grade;

	private void setGrade(double x){
		grade = x;
	}

}

package ca.uwo.csd.cs2212.team5;

public class Grade {
	double grade;

	private void setGrade(double x){
		grade = x;
	}

}
